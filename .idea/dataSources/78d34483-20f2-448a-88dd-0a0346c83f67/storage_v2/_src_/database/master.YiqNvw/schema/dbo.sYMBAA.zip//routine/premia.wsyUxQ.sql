CREATE PROCEDURE premia @id INT = -1, @procent INT = -1
AS
BEGIN
    IF @procent = -1 AND @id = -1
        BEGIN
            UPDATE siec_hoteli.dbo.pracownicy
            SET premia = 0
            WHERE premia IS NULL;
        END
    ELSE
        IF @procent = -1 AND @id != -1
            BEGIN
                UPDATE siec_hoteli.dbo.pracownicy
                SET premia = 0
                WHERE premia IS NULL
                  AND @id = id_pracownika
            END
        ELSE
            IF @procent != -1 AND @id != -1
                BEGIN
                    UPDATE siec_hoteli.dbo.pracownicy
                    SET premia = premia * ((100.00 + @procent) / 100.00)
                    WHERE @id = id_pracownika
                END
            ELSE
                BEGIN
                    DECLARE kursor_premia CURSOR FOR
                        SELECT id_pracownika FROM siec_hoteli.dbo.pracownicy
                    DECLARE @id_kr INT
                    BEGIN
                        OPEN kursor_premia
                        FETCH NEXT FROM kursor_premia INTO @id_kr
                        WHILE @@FETCH_STATUS = 0
                            BEGIN
                                UPDATE siec_hoteli.dbo.pracownicy
                                SET premia = premia * ((100.00 + @procent) / 100.00)
                                WHERE CURRENT OF kursor_premia
                                FETCH NEXT FROM kursor_premia INTO @id_kr
                            END
                        CLOSE kursor_premia
                        DEALLOCATE kursor_premia
                    END

                END

END
GO

