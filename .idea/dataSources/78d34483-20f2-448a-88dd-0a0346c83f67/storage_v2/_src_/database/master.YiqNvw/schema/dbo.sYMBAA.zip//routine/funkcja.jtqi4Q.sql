create function dbo.funkcja (@input varchar(3))
returns float
as begin
	declare @all_emp int;
	declare @emp_in_input int;
	select @all_emp = count(*) from hr..departments e
	select @emp_in_input = count(*) from  hr..locations l, hr..departments d where  l.location_id = d.location_id and l.country_id = @input

	return (cast(@emp_in_input as float) / cast(@all_emp as float)) * 100.0
end
GO

