CREATE PROCEDURE DRUGA
@first varchar(50) = null,
@second varchar(100) = 'DRUGA',
@third int = 1
AS
	declare @zmiennaznakowa varchar(100) = 'DRUGA'
RETURN @second
GO

