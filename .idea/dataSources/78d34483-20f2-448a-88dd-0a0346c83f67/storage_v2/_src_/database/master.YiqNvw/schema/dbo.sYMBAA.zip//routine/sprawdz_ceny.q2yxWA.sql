CREATE PROCEDURE [dbo].[sprawdz_ceny] @id_panstwa VARCHAR(2)
AS
BEGIN
    IF (SELECT AVG(h.cena_bazowa_za_pokoj)
        FROM siec_hoteli..miasta m,
             siec_hoteli..hotele h
        WHERE h.id_miasta = m.id_miasta
          AND m.id_panstwa = @id_panstwa) > (SELECT AVG(h2.cena_bazowa_za_pokoj) * 1.20 FROM siec_hoteli..hotele h2)
        BEGIN
            UPDATE siec_hoteli..hotele
            SET cena_bazowa_za_pokoj = cena_bazowa_za_pokoj * 0.92
            WHERE id_miasta IN (SELECT m.id_miasta FROM siec_hoteli..miasta m WHERE m.id_panstwa = @id_panstwa)
        END
    ELSE
        IF (SELECT AVG(h.cena_bazowa_za_pokoj)
            FROM siec_hoteli..miasta m,
                 siec_hoteli..hotele h
            WHERE h.id_miasta = m.id_miasta
              AND m.id_panstwa = @id_panstwa) < (SELECT AVG(h2.cena_bazowa_za_pokoj) * 0.8 FROM siec_hoteli..hotele h2)
            BEGIN
                UPDATE siec_hoteli..hotele
                SET cena_bazowa_za_pokoj = cena_bazowa_za_pokoj * 1.11
                WHERE id_miasta IN (SELECT m.id_miasta FROM siec_hoteli..miasta m WHERE m.id_panstwa = @id_panstwa)
            END
END
GO

