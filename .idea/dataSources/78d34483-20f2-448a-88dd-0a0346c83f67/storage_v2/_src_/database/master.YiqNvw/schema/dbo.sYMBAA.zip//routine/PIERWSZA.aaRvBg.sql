
CREATE PROCEDURE PIERWSZA
@first varchar(50)
AS
print('Wartosc parametru wynosila: ' + @first)
RETURN
go

