CREATE FUNCTION CZWARTA(@id int) returns float
as 
	begin
		declare @return_percentage float;
		declare @sum money;
		declare @sum_in_id  money;
		select @sum = sum(p.placa) from test_pracownicy..pracownicy p
		select @sum_in_id = sum(p.placa) from test_pracownicy..pracownicy p where p.id_dzialu = @id;
		set @return_percentage = ((@sum_in_id / @sum) * 100.0)
		return @return_percentage
	end
go

