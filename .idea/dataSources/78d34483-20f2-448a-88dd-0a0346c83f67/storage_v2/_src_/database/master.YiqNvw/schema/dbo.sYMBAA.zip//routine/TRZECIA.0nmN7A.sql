CREATE PROCEDURE TRZECIA
@id int = 1,
@procent int = 10
as
begin
	if @id = 0
	begin
		update test_pracownicy..pracownicy
		set placa = placa * (((@procent) / 100.0) + 1 )
	end
	else
	begin
		update test_pracownicy..pracownicy
		set placa = placa * (((@procent) / 100.0) + 1 )
		where id_dzialu  = @id
	end
	begin 
		insert into test_pracownicy..dziennik (tabela, data, l_wierszy, komunikat) values 
		('pracownicy', GETDATE(), @@ROWCOUNT, 'PODWYZSZONO PLACE O ' + cast(@procent as varchar) + ' PROCENT')
	end
end
go

