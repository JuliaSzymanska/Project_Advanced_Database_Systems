CREATE PROCEDURE premia_procedura @id INT = -1, @procent INT = 10
AS
BEGIN
    IF @id = -1
        BEGIN
            UPDATE siec_hoteli.dbo.pracownicy
            SET premia = 0
            WHERE premia IS NULL;


            UPDATE siec_hoteli.dbo.pracownicy
            SET premia = CASE
                             WHEN premia * ((100.00 + @procent) / 100.00) < 10
                                 THEN premia * ((100.00 + @procent) / 100.00)
                             ELSE premia
                END

        END
    ELSE
        BEGIN
            UPDATE siec_hoteli.dbo.pracownicy
            SET premia = 0
            WHERE premia IS NULL
              AND @id = id_pracownika

            UPDATE siec_hoteli.dbo.pracownicy
            SET premia = CASE
                             WHEN premia * ((100.00 + @procent) / 100.00) < 10
                                 THEN premia * ((100.00 + @procent) / 100.00)
                             ELSE premia
                END
            WHERE @id = id_pracownika
        END
END
GO

