CREATE PROCEDURE [dbo].[sprawdz_sprzatanie] @id_pokoju INT
AS
BEGIN
    IF NOT EXISTS(SELECT s.id_pokoju
                  FROM siec_hoteli..sprzatanie s,
                       siec_hoteli..pokoje p,
                       siec_hoteli..rezerwacje r
                  WHERE s.id_pokoju = @id_pokoju
                    AND r.id_pokoju = @id_pokoju
                    AND p.id_pokoju = @id_pokoju
                    AND r.id_rezerwacji = (SELECT TOP 1 r1.id_rezerwacji
                                           FROM siec_hoteli..rezerwacje r1
                                           WHERE r1.id_pokoju = @id_pokoju
                                             AND r1.data_rezerwacji < GETDATE()
                                           ORDER BY r1.data_rezerwacji DESC)
                    AND DATEADD(DAY, r.liczba_dni_rezerwacji, r.data_rezerwacji) < s.data_rozpoczecia_sprzatania
                    AND s.id_sprzatania = (SELECT TOP 1 s1.id_sprzatania
                                           FROM siec_hoteli..sprzatanie s1
                                           WHERE s1.id_pokoju = @id_pokoju
                                           ORDER BY s1.data_rozpoczecia_sprzatania DESC))
        PRINT ('Pokoj nie byl sprzatany')
    ELSE
        PRINT ('Pokoj byl sprzatany')
END
GO

