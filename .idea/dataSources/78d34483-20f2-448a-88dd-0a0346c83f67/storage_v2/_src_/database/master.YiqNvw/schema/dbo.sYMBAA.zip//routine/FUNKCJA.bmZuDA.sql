CREATE FUNCTION dbo.FUNKCJA(@data_zatr DATE) returns varchar(10)
as 
	begin
		if month(@data_zatr) in (1, 2, 3)
		begin
			return 'I'
		end
		if month(@data_zatr) in (4, 5, 6)
		begin
			return 'II'
		end
		if month(@data_zatr) in (7, 8, 9)
		begin
			return 'IKS'
		end
		return 'IV'
	end
go

