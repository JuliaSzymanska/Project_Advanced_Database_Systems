CREATE PROCEDURE [dbo].[ustaw_cene_calkowita] @id_rezerwacji INT
AS
BEGIN
    UPDATE siec_hoteli..archiwum_rezerwacji
    SET cena_calkowita = cena_za_uslugi + cena_za_telefon + cena_wynajecia_pokoju
    WHERE archiwum_rezerwacji.id_rezerwacji = @id_rezerwacji
END
GO

