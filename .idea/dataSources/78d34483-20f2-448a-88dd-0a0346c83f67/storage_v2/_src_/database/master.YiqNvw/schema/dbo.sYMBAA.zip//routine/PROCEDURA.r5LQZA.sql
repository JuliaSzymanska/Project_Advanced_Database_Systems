CREATE PROCEDURE PROCEDURA
@miasto varchar(30) = 'Toronto'
AS
begin
	select e.* from hr..employees e, hr..locations l, hr..departments d where e.department_id = d.department_id and d.location_id = l.location_id and l.city = @miasto
	RETURN
end
go

