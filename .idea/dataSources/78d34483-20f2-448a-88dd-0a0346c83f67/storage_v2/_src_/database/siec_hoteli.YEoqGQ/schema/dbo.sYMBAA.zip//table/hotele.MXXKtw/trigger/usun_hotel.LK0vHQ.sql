CREATE TRIGGER usun_hotel
    ON siec_hoteli.dbo.hotele
    INSTEAD OF DELETE
    AS
BEGIN
    BEGIN
        UPDATE siec_hoteli..pracownicy
        SET id_hotelu = NULL
        WHERE id_hotelu IN (SELECT d.id_hotelu FROM deleted d)
    END

    DECLARE kursor CURSOR FOR
        SELECT p.id_pracownika, p.id_hotelu
        FROM siec_hoteli..pracownicy p

    DECLARE @id_prac INT, @id_hotel INT

    BEGIN
        OPEN kursor
        FETCH NEXT FROM kursor INTO @id_prac, @id_hotel
        WHILE @@FETCH_STATUS = 0
            BEGIN
                IF @id_hotel IS NULL
                    BEGIN
                        IF NOT EXISTS(SELECT *
                                      FROM siec_hoteli..archiwum_pracownikow p
                                      WHERE p.id_pracownika = @id_prac)
                            BEGIN
                                INSERT INTO siec_hoteli..archiwum_pracownikow(koniec_pracy, id_pracownika)
                                VALUES (GETDATE(), @id_prac)
                            END
                    END
                FETCH NEXT FROM kursor INTO @id_prac, @id_hotel
            END
        CLOSE kursor
        DEALLOCATE kursor
    END
    BEGIN
        DELETE FROM siec_hoteli..hotele WHERE id_hotelu IN (SELECT d.id_hotelu FROM deleted d)
    END
END
GO

