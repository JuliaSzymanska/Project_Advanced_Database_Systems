CREATE TRIGGER ustaw_cene_archiwum
    ON siec_hoteli.dbo.archiwum_rezerwacji
    AFTER INSERT
    AS
    DECLARE
        @id_rez INT
DECLARE kursor CURSOR FOR
    SELECT id_rezerwacji
    FROM inserted

BEGIN
	PRINT 'Siemka jestem w triggerze'
    OPEN kursor
    FETCH NEXT FROM kursor INTO @id_rez
    WHILE @@FETCH_STATUS = 0
        BEGIN
            EXEC [dbo].[ustaw_cene_za_telefon] @id_rez
            EXEC [dbo].[ustaw_cene_za_uslugi] @id_rez
            EXEC [dbo].[ustaw_cene_za_wynajecie_pokoju] @id_rez
            EXEC [dbo].[ustaw_cene_calkowita] @id_rez
            FETCH NEXT FROM kursor INTO @id_rez
        END
    CLOSE kursor
    DEALLOCATE kursor
END
GO

