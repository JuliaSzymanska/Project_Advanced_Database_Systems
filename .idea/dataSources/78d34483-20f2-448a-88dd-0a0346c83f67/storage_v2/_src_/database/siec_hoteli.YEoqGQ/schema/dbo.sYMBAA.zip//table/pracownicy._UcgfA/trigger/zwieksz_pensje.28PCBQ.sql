CREATE TRIGGER zwieksz_pensje
    ON siec_hoteli.dbo.pracownicy
    INSTEAD OF UPDATE
    AS
    IF (UPDATE(premia))
        BEGIN
            UPDATE dbo.pracownicy
            SET dbo.pracownicy.pensja += i.pensja * i.premia * 0.5
            FROM inserted i
            WHERE dbo.pracownicy.id_pracownika = i.id_pracownika
              AND (i.premia - dbo.pracownicy.premia) > 0.1

            UPDATE dbo.pracownicy
            SET premia = i.premia
            FROM inserted i
            WHERE dbo.pracownicy.id_pracownika = i.id_pracownika

        END
GO

