CREATE TRIGGER czy_rezerwacja_moze_byc_dodana
    ON siec_hoteli.dbo.rezerwacje
    INSTEAD OF INSERT
    AS
    DECLARE
        @id_rezerwacji         INT,
        @data_rezerwacji       DATE,
        @liczba_dni_rezerwacji INT,
        @id_pokoju             INT,
        @id_klienta            INT
DECLARE kursor CURSOR FOR
    SELECT i.id_rezerwacji, i.data_rezerwacji, i.liczba_dni_rezerwacji, i.id_pokoju, i.id_klienta
    FROM inserted i
BEGIN
    OPEN kursor
    FETCH NEXT FROM kursor INTO @id_rezerwacji, @data_rezerwacji, @liczba_dni_rezerwacji, @id_pokoju, @id_klienta
    WHILE @@FETCH_STATUS = 0
        BEGIN
            IF NOT EXISTS(SELECT *
                          FROM siec_hoteli..rezerwacje r
                          WHERE ((r.data_rezerwacji > @data_rezerwacji
                              AND r.data_rezerwacji <
                                  DATEADD(DAY, @liczba_dni_rezerwacji, @data_rezerwacji))
                              OR (DATEADD(DAY, r.liczba_dni_rezerwacji, r.data_rezerwacji) >
                                  @data_rezerwacji AND
                                  DATEADD(DAY, r.liczba_dni_rezerwacji, r.data_rezerwacji) <
                                  DATEADD(DAY, @liczba_dni_rezerwacji, @data_rezerwacji))))
                BEGIN
                    INSERT INTO siec_hoteli..rezerwacje (data_rezerwacji, liczba_dni_rezerwacji, id_pokoju, id_klienta)
                    VALUES (@data_rezerwacji, @liczba_dni_rezerwacji, @id_pokoju, @id_klienta)
                END
            ELSE
                RAISERROR ('Ten pokoj jest juz zajety w tym terminie.', 14, 1)
            FETCH NEXT FROM kursor INTO @id_rezerwacji, @data_rezerwacji, @liczba_dni_rezerwacji, @id_pokoju, @id_klienta
        END
    CLOSE kursor
    DEALLOCATE kursor
END
GO

